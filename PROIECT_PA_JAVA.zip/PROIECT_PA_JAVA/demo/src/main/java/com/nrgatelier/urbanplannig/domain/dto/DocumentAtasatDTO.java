package com.nrgatelier.urbanplannig.domain.dto;

public record DocumentAtasatDTO(
        int id,
        String numeFile
) {
}
