package com.nrgatelier.urbanplannig.domain.entities;

public enum LocatieTeren {
    INTRAVILAN,
    EXTRAVILAN,
    PARTIAL_INTRAVILAN,
    NECUNOSCUT,
    JUDET,
    LOCALITATE
}
