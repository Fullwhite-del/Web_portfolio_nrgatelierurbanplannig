package com.nrgatelier.urbanplannig.controllers;

import com.nrgatelier.urbanplannig.domain.dto.ContactDTO;
import com.nrgatelier.urbanplannig.services.ContactService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/cereri")
@CrossOrigin(origins = "*") // Legatura dintre Backend si Frontend, permite primirea de pachete de la alte adrese CORS = Cross-Origin Resource Sharing
public class ContactController {

    private final ContactService contactService;

    public ContactController(ContactService contactService) {
        this.contactService = contactService;
    }

    // Link-ul final va fi: http://localhost:8080/api/cereri/trimite
    @PostMapping("/trimite")
    public ResponseEntity<String> trimiteCerere(

            @Valid @RequestPart("formular") ContactDTO formular,

            @RequestPart(value = "fisiere", required = false) List<MultipartFile> fisiere) {

        contactService.salveazaCerereNoua(formular, fisiere);

        return ResponseEntity.ok("Cererea si fișierele au fost salvate cu succes in baza de date!");
    }
    @GetMapping("/toate")
    public ResponseEntity<List<ContactDTO>> citesteToateCererile() {

        List<ContactDTO> listaCereri = contactService.preiaToateCererile();

        return ResponseEntity.ok(listaCereri);
    }

    @GetMapping("/fisiere/{numeFisier:.+}")
    public ResponseEntity<org.springframework.core.io.Resource> afiseazaFisier(@PathVariable String numeFisier) throws Exception {

        java.nio.file.Path caleCatreFisier = java.nio.file.Paths.get("C:/uploads/" + numeFisier);
        org.springframework.core.io.Resource resursa = new org.springframework.core.io.UrlResource(caleCatreFisier.toUri());

        if (!resursa.exists()) {
            return ResponseEntity.notFound().build(); // Eroare 404 dacă poza nu existe
        }

        // 3. Ghicim tipul fisierului (e .jpg? e .png? e .pdf?) ca sa stie browser-ul cum să-l deseneze
        String tipFisier = java.nio.file.Files.probeContentType(caleCatreFisier);
        if (tipFisier == null) {
            tipFisier = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .contentType(org.springframework.http.MediaType.parseMediaType(tipFisier))
                .body(resursa);
    }
}