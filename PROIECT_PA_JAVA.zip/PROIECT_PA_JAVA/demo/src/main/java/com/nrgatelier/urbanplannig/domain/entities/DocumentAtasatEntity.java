package com.nrgatelier.urbanplannig.domain.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Setter
@Getter
@Table(name = "Documente")
public class DocumentAtasatEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "NumeFisier", updatable = false, nullable = false)
    private String numeFile;

    @Column(name = "CaleFisier", updatable = false, nullable = false)
    private String pathFile;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contact_id", nullable = false)
    private ContactEntity contact;

}
