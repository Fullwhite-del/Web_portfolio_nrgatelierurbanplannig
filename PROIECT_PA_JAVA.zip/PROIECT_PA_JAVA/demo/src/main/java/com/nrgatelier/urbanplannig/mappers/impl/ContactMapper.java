package com.nrgatelier.urbanplannig.mappers.impl;


import com.nrgatelier.urbanplannig.domain.entities.ContactEntity;
import com.nrgatelier.urbanplannig.domain.dto.ContactDTO;
import org.springframework.stereotype.Component;

@Component
public class ContactMapper {

    public ContactEntity toContactEntity(ContactDTO dto) {
        if(dto == null)
            return null;

        ContactEntity entity = new ContactEntity();

        // tipuul cererii
        entity.setAreCertificatUrbanism(dto.areCertificatUrbanism());

        // varibilele comune
        entity.setFirstName(dto.firstName());
        entity.setLastName(dto.lastName());
        entity.setEmail(dto.email());
        entity.setPhone(dto.phone());
        entity.setArieTeren(dto.arieTeren());
        entity.setLocatieTeren(dto.locatieTeren());
        entity.setAdresaExacta(dto.adresaExacta());
        entity.setNrCadastral(dto.nrCadastral());
        entity.setNrCarteFunciara(dto.nrCarteFunciara());
        entity.setRegimJuridic(dto.regimJuridic());

        //DA:
        entity.setScopProiect(dto.scopProiect());

        //NU:
        entity.setInvestitie(dto.investitie());
        entity.setStareTeren(dto.stareTeren());

        return entity;
    }

    // Traducerea inversă: din Baza de date (Entity) catre Internet (DTO)
    public ContactDTO toContactDTO(ContactEntity entity) {
        if (entity == null) {
            return null;
        }

        // La un 'record', construim pachetul dintr-o singura miscare,
        // respectand ordinea exacta a variabilelor din ContactDTO.java
        return new ContactDTO(
                entity.isAreCertificatUrbanism(), // sau getAreCertificatUrbanism() dacă îți dă eroare cu is...
                entity.getFirstName(),
                entity.getLastName(),
                entity.getEmail(),
                entity.getPhone(),
                entity.getArieTeren(),
                entity.getLocatieTeren(),
                entity.getAdresaExacta(),
                entity.getNrCadastral(),
                entity.getNrCarteFunciara(),
                entity.getRegimJuridic(),
                entity.getScopProiect(),
                entity.getInvestitie(),
                entity.getStareTeren()
        );
    }
}
