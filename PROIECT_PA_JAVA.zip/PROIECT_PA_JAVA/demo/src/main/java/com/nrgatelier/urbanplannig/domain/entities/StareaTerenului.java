package com.nrgatelier.urbanplannig.domain.entities;

public enum StareaTerenului {
    CONSTRUIT,
    NECONSTRUIT
}
