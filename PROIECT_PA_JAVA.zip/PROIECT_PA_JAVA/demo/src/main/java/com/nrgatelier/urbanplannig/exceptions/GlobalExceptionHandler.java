package com.nrgatelier.urbanplannig.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // Aceasta functie asteapta o eroare. Cand prinde o eroare de validare (MethodArgumentNotValidException) atunci erunca exceptia personalizata
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {

        Map<String, String> errors = new HashMap<>();

        // Luam toate erorile din pachetul respins
        ex.getBindingResult().getAllErrors().forEach((error) ->
        {
            // Extragem numele variabilei care a picat (ex: "firstName")
            String fieldName = ((FieldError) error).getField();
            // Extragem mesajul personalizat (ex: "Acest camp trebuie sa fie completat")
            String errorMessage = error.getDefaultMessage();

            errors.put(fieldName, errorMessage);
        });

        return errors;
    }
}