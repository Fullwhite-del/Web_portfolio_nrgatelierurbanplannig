package com.nrgatelier.urbanplannig.domain.dto;

import com.nrgatelier.urbanplannig.domain.entities.LocatieTeren;
import com.nrgatelier.urbanplannig.domain.entities.RegimJuridic;
import com.nrgatelier.urbanplannig.domain.entities.StareaTerenului;
import jakarta.validation.constraints.*;

public record ContactDTO(

        // tipuul cererii
        boolean areCertificatUrbanism,

        // varibilele comune
        @NotBlank(message = "Acest camp trebuie sa fie completat, nu trebuie sa aiba spatii goale")
        String firstName,

        @NotBlank(message = "Acest camp trebuie sa fie completat, nu trebuie sa aiba spatii goale")
        String lastName,

        @NotBlank
        @Email(message = "Mail-ul completat nu este corect")
        String email,

        @NotBlank(message = "Acest camp trebuie sa fie completat, nu trebuie sa aiba spatii goale")
        String phone,

        // nu pun niciun @ aici!
        double arieTeren,

        @NotNull(message = "Acest camp trebuie sa fie completat, nu trebuie sa aiba spatii goale")
        LocatieTeren locatieTeren,

        @NotBlank(message = "Acest camp trebuie sa fie completat, nu trebuie sa aiba spatii goale")
        String adresaExacta,

        @NotBlank(message = "Acest camp trebuie sa fie completat")
        String nrCadastral,

        @NotBlank(message = "Acest camp trebuie sa fie completat")
        String nrCarteFunciara,

        @NotNull (message = "Acest camp trebuie sa fie completat") // la asta nu trebuie sa fie completat cu exact ce am in RegimJuridic?
        RegimJuridic regimJuridic,

        // DA:
        @NotBlank(message = "Acest camp trebuie sa fie completat, nu trebuie sa aiba spatii goale")
        String scopProiect,
        // lista nu o pun aici, pentru ca dto trimite pachete sub format json, documentele sunt fisiere binare

        //NU:
        @NotBlank(message = "Acest camp trebuie sa fie completat, nu trebuie sa aiba spatii goale")
        String investitie,

        @NotNull(message = "Acest camp trebuie sa fie completat, nu trebuie sa aiba spatii goale")
        StareaTerenului stareTeren
) {
}
