package com.nrgatelier.urbanplannig.domain.entities;

public enum RequiredEntity {
    REQUIRED_ENTITIES, OPTIONAL_ENTITIES            // NU ARE ROST DAR POATE GASESC CEVA PT EA CARE SA FIE FOLOSIT CUM TREBUIE
    // MERE CA UN DROP-DOWN BUTTON GEN

}
