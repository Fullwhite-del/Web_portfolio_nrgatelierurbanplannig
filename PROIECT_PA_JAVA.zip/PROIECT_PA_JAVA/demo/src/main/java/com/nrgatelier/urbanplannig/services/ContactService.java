package com.nrgatelier.urbanplannig.services;


import com.nrgatelier.urbanplannig.Repositories.ContactRepository;
import com.nrgatelier.urbanplannig.domain.dto.ContactDTO;
import com.nrgatelier.urbanplannig.domain.entities.ContactEntity;
import com.nrgatelier.urbanplannig.domain.entities.DocumentAtasatEntity;
import com.nrgatelier.urbanplannig.mappers.impl.ContactMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
public class ContactService {
    private final ContactRepository contactRepository;
    private final ContactMapper contactMapper;

    public ContactService(ContactRepository contactRepository, ContactMapper contactMapper) {
        this.contactRepository = contactRepository;
        this.contactMapper = contactMapper;
    }

    public void salveazaCerereNoua(ContactDTO formular, List<MultipartFile> fisiere)
    {
        ContactEntity contact = contactMapper.toContactEntity(formular);

        if(fisiere != null && !fisiere.isEmpty())
        {
            String folderDestinatie = "C:/uploads/";
            new File(folderDestinatie).mkdirs();

            for(MultipartFile fisierBrut : fisiere)
            {
                if(!fisierBrut.isEmpty())
                {
                    String caleFisier = folderDestinatie + fisierBrut.getOriginalFilename();
                    try {
                        fisierBrut.transferTo(new File(caleFisier));

                        // B. Construirea "dosarului" pentru baza de date
                        DocumentAtasatEntity document = new DocumentAtasatEntity();
                        document.setNumeFile(fisierBrut.getOriginalFilename());
                        document.setPathFile(caleFisier);

                        // C. Legam documentul de contact (ManyToOne)
                        document.setContact(contact);

                        // D. Bagam documentul in lista contactului
                        contact.getDocumentAtasat().add(document);

                    } catch (IOException e) {
                        System.out.println("Eroare la salvarea fișierului: " + e.getMessage());
                    }
                }

            }
        }
        contactRepository.save(contact);
    }

    // Funcția care citește toate dosarele din baza de date
    public List<ContactDTO> preiaToateCererile() {

        // Scoatem absolut toate dosarele (Entitațile) din baza de date
        List<ContactEntity> toateEntitatile = contactRepository.findAll();

        // Trecem fiecare dosar pe rand prin traducatorul nostru (Mapper)
        // si le punem pe toate intr-o lista noua de DTO-uri gata de trimis pe internet
        return toateEntitatile.stream().map(entitate -> contactMapper.toContactDTO(entitate)).toList();
    }
}
