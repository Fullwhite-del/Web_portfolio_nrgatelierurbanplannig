package com.nrgatelier.urbanplannig.Repositories;

import com.nrgatelier.urbanplannig.domain.entities.DocumentAtasatEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentAtasatRepositories extends JpaRepository<DocumentAtasatEntity, Integer> {
}
