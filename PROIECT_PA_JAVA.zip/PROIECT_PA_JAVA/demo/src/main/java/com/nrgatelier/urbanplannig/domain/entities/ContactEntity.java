package com.nrgatelier.urbanplannig.domain.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import java.util.*; // import java.util.UUID; face parte din '*'

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "Contact")
public class ContactEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id",updatable = false ,nullable = false)
    private UUID id;

    //  TIPUL CERERII
    @Column(name = "CertificatUrb", updatable = false, nullable = false)
    private boolean areCertificatUrbanism; // true pentru "Da", false pentru "Nu"

    // VARIABILE COMUNE - Se folosesc și la DA și la NU
    @Column(name = "Prenume", nullable = false)
    private String firstName;
    @Column(name = "Nume", nullable = false)
    private String lastName;
    @Column(name = "Email", nullable = false)
    private String email;
    @Column(name = "NrTel", nullable = false)
    private String phone;

    @Column(name = "ArieTeren", updatable = false, nullable = false)
    private double arieTeren; //mp sau ha

    @Column(name = "LocatieTeren", updatable = false, nullable = true)
    @Enumerated(EnumType.STRING)
    private LocatieTeren locatieTeren; // (optional)

    @Column(name = "AdresaExacta", updatable = false, nullable = true)
    private String adresaExacta; // (optional)

    @Column(name = "NrCadastral", updatable = false, nullable = false, length = 30)
    private String nrCadastral;

    @Column(name = "NrCarteFunciara", updatable = false, nullable = false, length = 30)
    private String nrCarteFunciara;

    @Column(name = "RegimJuridic", updatable = false, nullable = false)
    @Enumerated(EnumType.STRING)
    private RegimJuridic regimJuridic;


    // DACA RASPUNSUL ESTE DA:
    @Column(name = "ScopProiect", updatable = false, nullable = false)
    private String scopProiect; // (ex.: dezvoltare rezidențială, industrială, comercială, mixtă)

    //variabila pt adaugat fisiere
    @OneToMany(mappedBy = "contact", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DocumentAtasatEntity> documentAtasat = new ArrayList<>();

    // DACA RASPUNSUL ESTE NU:
    @Column(name = "Investitie", updatable = false, nullable = true)
    private String investitie;

    @Column(name = "StareTeren", updatable = false, nullable = true)
    @Enumerated(EnumType.STRING)
    private StareaTerenului stareTeren;
}
