package com.nrgatelier.urbanplannig.domain.entities;

public enum RegimJuridic {
    PROPRIETATE_PRIVATA,
    CESIUNE,
    LITIGIU
}
