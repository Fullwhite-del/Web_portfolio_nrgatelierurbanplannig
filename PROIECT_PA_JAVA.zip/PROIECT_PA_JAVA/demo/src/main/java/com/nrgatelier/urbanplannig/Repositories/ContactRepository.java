package com.nrgatelier.urbanplannig.Repositories;

import com.nrgatelier.urbanplannig.domain.entities.ContactEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ContactRepository extends JpaRepository<ContactEntity, UUID> {
}
