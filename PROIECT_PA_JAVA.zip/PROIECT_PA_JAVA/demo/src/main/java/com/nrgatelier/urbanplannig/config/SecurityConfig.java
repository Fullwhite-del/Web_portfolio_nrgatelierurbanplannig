package com.nrgatelier.urbanplannig.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration //clasa mea devine un panou de configurari
@EnableWebSecurity //activeaza securitatea pe toate rutele existente
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception // filtru ce reprezinta internetul
    {
        http // (http-ul pe care aplicam filtrul)
                .cors(Customizer.withDefaults()) // activam 'podul' CORS in fata securitatii

                .csrf(csrf -> csrf.disable()) // Cross-Site Request Forgery masura de protectie care cere un token pentru orice POST

                .authorizeHttpRequests(auth -> auth

                        .requestMatchers(HttpMethod.POST, "/api/cereri/trimite").permitAll() // pentru aceasta cale lasa pe oricine

                        .anyRequest().authenticated() // restul cailor necesita token de acces
                )
                .httpBasic(Customizer.withDefaults()); // mod logare: username si parola

        return http.build();
    }
}