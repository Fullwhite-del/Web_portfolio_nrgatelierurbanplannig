package com.nrgatelier.urbanplannig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class nrgatelierApplication {

	public static void main(String[] args) {
		SpringApplication.run(nrgatelierApplication.class, args);
	}

}