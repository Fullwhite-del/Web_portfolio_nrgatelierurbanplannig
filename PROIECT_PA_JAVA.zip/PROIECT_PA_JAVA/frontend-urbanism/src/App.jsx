import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Contact from './pages/Contact';
import Admin from './pages/Admin'; // Le vom activa cand le punem codul
import Home from './pages/Home';
import './App.css';

function App() {
    return (
        <BrowserRouter>
            {/* BARA DE NAVIGATIE (Apare pe toate paginile) */}
            <nav style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '20px 50px',
                backgroundColor: '#1a1a1a', // Un gri inchis, elegant
                borderBottom: '1px solid #333'
            }}>
                {/* LOGO-ul din stanga */}
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: 'white', letterSpacing: '1px' }}>
                    URBAN<span style={{ color: '#007bff' }}>PLANNING</span>
                </div>

                {/* MENIUL din dreapta */}
                <div style={{ display: 'flex', gap: '30px' }}>
                    <Link to="/" style={linkStyle}>Acasă / Portofoliu</Link>
                    <Link to="/contact" style={linkStyle}>Depune Dosar</Link>
                    <Link to="/admin" style={linkStyle}>Admin (Secret)</Link>
                </div>
            </nav>

            {/* ZONA DE CONTINUT (Se schimba in functie de pagina) */}
            <div style={{ padding: '40px' }}>
                <Routes>
                    {/* Ușa 1: Pagina principală */}
                    <Route path="/" element={<Home />} />

                    {/* Ușa 2: Formularul Clientului */}
                    <Route path="/contact" element={<Contact />} />

                    {/* Ușa 3: Panoul tău de control */}
                    <Route path="/admin" element={<Admin />} />
                </Routes>
            </div>
        </BrowserRouter>
    );
}

// Un stil rapid pentru butoanele din meniu, ca sa arate bine
const linkStyle = {
    color: '#e0e0e0',
    textDecoration: 'none',
    fontSize: '16px',
    fontWeight: '500',
    transition: 'color 0.3s'
};

export default App;