import { Link } from 'react-router-dom';

function Home() {
    return (
        <div style={{ maxWidth: '1000px', margin: '0 auto', textAlign: 'center', padding: '40px 20px' }}>

            {/* SECTIUNEA HERO (Banner-ul Principal) */}
            <div style={{ padding: '80px 20px', borderBottom: '1px solid #333' }}>
                <h1 style={{ fontSize: '3rem', margin: '0 0 20px 0', fontWeight: 'bold', lineHeight: '1.2' }}>
                    Proiectăm viitorul, <br />
                    <span style={{ color: '#007bff' }}>parcelă cu parcelă.</span>
                </h1>
                <p style={{ fontSize: '1.2rem', color: '#aaa', maxWidth: '600px', margin: '0 auto 40px auto', lineHeight: '1.6' }}>
                    Suntem un birou de urbanism dedicat transformării viziunilor în realitate.
                    Oferim consultanță, elaborare PUZ/PUD și asistență pentru obținerea certificatelor de urbanism.
                </p>

                {/* Buton care te duce direct la formular */}
                <Link to="/contact" style={{
                    padding: '15px 30px',
                    backgroundColor: '#007bff',
                    color: 'white',
                    textDecoration: 'none',
                    borderRadius: '5px',
                    fontSize: '1.1rem',
                    fontWeight: 'bold',
                    transition: 'background-color 0.3s'
                }}>
                    Începe un Proiect Nou
                </Link>
            </div>

            {/* SECTIUNEA DE SERVICII / PORTOFOLIU */}
            <div style={{ padding: '60px 0' }}>
                <h2 style={{ fontSize: '2rem', marginBottom: '40px' }}>Serviciile Noastre</h2>

                <div style={{ display: 'flex', gap: '20px', justifyContent: 'center', flexWrap: 'wrap' }}>

                    {/* Card Serviciu 1 */}
                    <div style={cardStyle}>
                        <h3 style={{ color: '#007bff' }}>Documentații Urbanism</h3>
                        <p style={{ color: '#ccc', lineHeight: '1.5' }}>Elaborăm Planuri Urbanistice Zonale (PUZ) și de Detaliu (PUD) respectând normele în vigoare.</p>
                    </div>

                    {/* Card Serviciu 2 */}
                    <div style={cardStyle}>
                        <h3 style={{ color: '#007bff' }}>Consultanță Tehnică</h3>
                        <p style={{ color: '#ccc', lineHeight: '1.5' }}>Te ghidăm în labirintul legislativ pentru obținerea avizelor și autorizațiilor de construire.</p>
                    </div>

                    {/* Card Serviciu 3 */}
                    <div style={cardStyle}>
                        <h3 style={{ color: '#007bff' }}>Studii de Fezabilitate</h3>
                        <p style={{ color: '#ccc', lineHeight: '1.5' }}>Analizăm potențialul terenului tău pentru a maximiza investiția într-un mod sustenabil.</p>
                    </div>

                </div>
            </div>

        </div>
    );
}

// Un mic stil pentru cardurile de servicii ca sa nu aglomeram codul de sus
const cardStyle = {
    backgroundColor: '#222',
    padding: '30px',
    borderRadius: '8px',
    width: '300px',
    border: '1px solid #444',
    textAlign: 'left',
    boxShadow: '0 4px 6px rgba(0,0,0,0.3)'
};

export default Home;