import { useState } from 'react';

function Contact() {
    // 1. Un singur SEIF pentru toate datele de tip text/numere
    const [formular, setFormular] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        areCertificatUrbanism: false, // Checkbox-ul e false la început
        arieTeren: '',
        locatieTeren: 'INTRAVILAN',   // Valoarea standard pentru dropdown
        adresaExacta: '',
        nrCadastral: '',
        nrCarteFunciara: '',
        regimJuridic: '',
        scopProiect: '',
        investitie: '',
        stareTeren: ''
    });

    // Seiful pentru poză rămâne separat
    const [fisier, setFisier] = useState(null);
    const [mesajServer, setMesajServer] = useState('');

    // Funcție inteligentă care prinde orice modificare din orice căsuță
    const actualizeazaCamp = (e) => {
        const { name, value, type, checked } = e.target;
        // Dacă e checkbox luăm "checked", dacă e text luăm "value"
        const valoareFinala = type === 'checkbox' ? checked : value;

        setFormular({
            ...formular, // Păstrăm restul datelor intacte
            [name]: valoareFinala // Actualizăm doar câmpul pe care se scrie acum
        });
    };

    const trimiteDatele = (e) => {
        e.preventDefault();
        setMesajServer('Se trimite...');

        const colet = new FormData();

        // Acum punem DIRECT tot seiful nostru în colet
        const formularBlob = new Blob([JSON.stringify(formular)], { type: 'application/json' });
        colet.append("formular", formularBlob);

        if (fisier) {
            colet.append("fisiere", fisier);
        }

        fetch('http://localhost:8080/api/cereri/trimite', {
            method: 'POST',
            body: colet
        })
            .then((raspuns) => {
                if (!raspuns.ok) throw new Error("Te rog verifică dacă ai completat corect datele!");
                return raspuns.text();
            })
            .then((text) => setMesajServer("✅ " + text))
            .catch((eroare) => setMesajServer("❌ Eroare: " + eroare.message));
    };

    return (
        <div style={{ maxWidth: '600px', margin: '0 auto', textAlign: 'left', paddingBottom: '50px', lineHeight: '1.2' }}>
            <h1>Depune un Dosar Complet 📁</h1>

            <form onSubmit={trimiteDatele} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>

                {/* Row 1: Nume si Prenume */}
                <div style={{ display: 'flex', gap: '10px' }}>
                    <div style={{ flex: 1 }}>
                        <label>Prenume:</label><br/>
                        <input type="text" name="firstName" value={formular.firstName} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label>Nume de familie:</label><br/>
                        <input type="text" name="lastName" value={formular.lastName} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                </div>

                {/* Row 2: Contact */}
                <div style={{ display: 'flex', gap: '10px' }}>
                    <div style={{ flex: 1 }}>
                        <label>Email:</label><br/>
                        <input type="email" name="email" value={formular.email} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label>Telefon:</label><br/>
                        <input type="text" name="phone" value={formular.phone} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                </div>

                {/* Teren Detalii */}
                <div>
                    <label>Locație Teren:</label><br/>
                    <select name="locatieTeren" value={formular.locatieTeren} onChange={actualizeazaCamp} style={{ width: '100%', padding: '8px' }}>
                        <option value="INTRAVILAN">Intravilan</option>
                        <option value="EXTRAVILAN">Extravilan</option>
                    </select>
                </div>

                <div>
                    <label>Adresa Exactă:</label><br/>
                    <input type="text" name="adresaExacta" value={formular.adresaExacta} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                    <div style={{ flex: 1 }}>
                        <label>Arie Teren (mp):</label><br/>
                        <input type="number" step="0.01" name="arieTeren" value={formular.arieTeren} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label>Nr. Cadastral:</label><br/>
                        <input type="text" name="nrCadastral" value={formular.nrCadastral} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                </div>
                {/* Rând nou: Detalii Juridice */}
                <div style={{ display: 'flex', gap: '10px' }}>
                    <div style={{ flex: 1 }}>
                        <label>Nr. Carte Funciară:</label><br/>
                        <input type="text" name="nrCarteFunciara" value={formular.nrCarteFunciara} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label>Regim Juridic (ex: Concesiune):</label><br/>
                        <input type="text" name="regimJuridic" value={formular.regimJuridic} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                </div>

                {/* Rând nou: Investiție și Stare */}
                <div style={{ display: 'flex', gap: '10px' }}>
                    <div style={{ flex: 1 }}>
                        <label>Investiție (ex: Fonduri proprii):</label><br/>
                        <input type="text" name="investitie" value={formular.investitie} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label>Stare Teren (ex: Neconstruit):</label><br/>
                        <input type="text" name="stareTeren" value={formular.stareTeren} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                    </div>
                </div>

                <div>
                    <label>Scopul Proiectului (ex: Construire casă):</label><br/>
                    <input type="text" name="scopProiect" value={formular.scopProiect} onChange={actualizeazaCamp} required style={{ width: '100%', padding: '8px' }} />
                </div>

                {/* Checkbox */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '10px' }}>
                    <input type="checkbox" name="areCertificatUrbanism" checked={formular.areCertificatUrbanism} onChange={actualizeazaCamp} style={{ width: '20px', height: '20px' }} />
                    <label>Am deja Certificat de Urbanism emis</label>
                </div>

                <hr style={{ width: '100%', margin: '10px 0' }} />

                <div>
                    <label>Atașează documente (PDF, JPG):</label><br/>
                    <input type="file" onChange={(e) => setFisier(e.target.files[0])} style={{ marginTop: '5px' }} />
                </div>

                <button type="submit" style={{ padding: '12px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', marginTop: '10px' }}>
                    Trimite Dosarul Oficial
                </button>

            </form>

            {mesajServer && (
                <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#2a2a2a', borderLeft: '5px solid #007bff', borderRadius: '4px' }}>
                    {mesajServer}
                </div>
            )}

        </div>
    );
}

export default Contact;