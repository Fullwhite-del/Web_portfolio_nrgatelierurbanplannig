import { useState, useEffect } from 'react';

function Admin() {
    const [cereri, setCereri] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8080/api/cereri/toate', {
            method: 'GET',
            headers: {
                'Authorization': 'Basic ' + btoa('admin:superparola123!')
            }
        })
            .then((raspuns) => raspuns.json())
            .then((dateCurate) => setCereri(dateCurate))
            .catch((eroare) => console.error("Eroare la aducerea datelor:", eroare));
    }, []);

    return (
        <div style={{ maxWidth: '800px', margin: '0 auto', textAlign: 'left' }}>
            <h1>Panou de Administrare 📂</h1>

            {cereri.length === 0 ? (
                <p>Se aduc dosarele din arhivă... te rog așteaptă.</p>
            ) : (
                cereri.map((cerere, index) => (
                    <div key={index} style={{ border: '1px solid #444', margin: '15px 0', padding: '20px', borderRadius: '8px', backgroundColor: '#222' }}>
                        <h2 style={{ marginTop: '0', color: '#007bff' }}>Dosar: {cerere.firstName} {cerere.lastName}</h2>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                            <p><strong>Email:</strong> {cerere.email}</p>
                            <p><strong>Telefon:</strong> {cerere.phone}</p>
                            <p><strong>Adresa:</strong> {cerere.adresaExacta} ({cerere.locatieTeren})</p>
                            <p><strong>Arie:</strong> {cerere.arieTeren} mp</p>
                            <p><strong>Scop:</strong> {cerere.scopProiect}</p>
                            <p><strong>Nr. Cadastral:</strong> {cerere.nrCadastral}</p>
                        </div>
                    </div>
                ))
            )}
        </div>
    );
}

export default Admin;